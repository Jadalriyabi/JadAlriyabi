from flask import Flask, g, request, jsonify
import pyodbc
from connect_db import connect_db
import sys
import time, datetime


app = Flask(__name__)

@app.route('/')
def hello_world():
    return 'Hello, World!'

def get_db():
    """Opens a new database connection if there is none yet for the
    current application context.
    """
    if not hasattr(g, 'azure_db'):
        g.azure_db = connect_db()
        g.azure_db.autocommit = True
        g.azure_db.set_attr(pyodbc.SQL_ATTR_TXN_ISOLATION, pyodbc.SQL_TXN_SERIALIZABLE)
    return g.azure_db

@app.teardown_appcontext
def close_db(error):
    """Closes the database again at the end of the request."""
    if hasattr(g, 'azure_db'):
        g.azure_db.close()



@app.route('/login')
def login():
    username = request.args.get('username', "")
    password = request.args.get('password', "")
    cid = -1
    #print (username, password)
    conn = get_db()
    #print (conn)
    cursor = conn.execute("SELECT * FROM Customer WHERE username = ? AND password = ?", (username, password))
    data = cursor.fetchall()
    #print records
    if len(data) != 0:
        cid = data[0][0]
    response = {'cid': cid}
    return jsonify(response)




@app.route('/getRenterID')
def getRenterID():
    """
       This HTTP method takes mid as input, and
       returns cid which represents the customer who is renting the movie.
       If this movie is not being rented by anyone, return cid = -1
    """
    mid = int(request.args.get('mid', -1))

    # WRITE YOUR CODE HERE
   
    cid = -1
    conn = get_db()
    
    cursor = conn.execute(
        """SELECT cid FROM Rental WHERE mid = ? AND status = 'open' ORDER BY date_and_time ASC;""", (mid))
    data = cursor.fetchall()
   
    #print records
    if len(data) != 0:
        cid = data[0][0]
    
    response = {'cid': cid}

    return str(response)




@app.route('/getRemainingRentals')
def getRemainingRentals():
    """
        This HTTP method takes cid as input, and returns n which represents
        how many more movies that cid can rent.

        n = 0 means the customer has reached its maximum number of rentals.
    """
    cid = int(request.args.get('cid', -1))
    conn = get_db()
    # Tell ODBC that you are starting a multi-statement transaction
    conn.autocommit = False

    # WRITE YOUR CODE HERE
    count = conn.execute("""SELECT count(cid) FROM Rental 
                            WHERE cid = ? AND Status = 'open';""", 
                        (cid))
    
    data = count.fetchall()
   
    if len(data) != 0:
        countcid = data[0][0]

    pid = conn.execute("""SELECT pid from Customer 
                            WHERE cid = ?;""",
                        (cid))
    
    data = pid.fetchall()
    
    if len(data) != 0:
        pid = data[0][0]
    

    n = conn.execute("""SELECT max_movies- ? 
                        FROM RentalPlan 
                        WHERE pid = ?;""", 
                    (countcid, pid))

    data = n.fetchall()
    
    if len(data) != 0:
        n = data[0][0]

    conn.autocommit = True

    response = {"remain": n}
    return jsonify(response)


def currentTime():
    ts = time.time()
    return datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M:%S')


@app.route('/rent')
def rent():
    """
        This HTTP method takes cid and mid as input, and returns either "success" or "fail".

        It returns "fail" if C1, C2, or both are violated:
            C1. at any time a movie can be rented to at most one customer.
            C2. at any time a customer can have at most as many movies rented as his/her plan allows.
        Otherwise, it returns "success" and also updates the database accordingly.
    """
    cid = int(request.args.get('cid', -1))
    mid = int(request.args.get('mid', -1))

    conn = get_db()

    # Tell ODBC that you are starting a multi-statement transaction
    conn.autocommit = False

    # WRITE YOUR CODE HERE
    response = {"rent": "success"}
    
    #flag
    success = 0

    #C1
    count_mid = conn.execute("""SELECT count(mid) 
                                FROM Rental 
                                WHERE mid = ? AND Status = 'open';""",
                            (mid))
    
    data = count_mid.fetchall()
   
    if len(data) != 0:
        count_mid = data[0][0]
    
    if count_mid > 0:
        response = {"rent": "fail"}
        success = 1
    
    #C2
    count_cursor = conn.execute("""SELECT count(cid) 
                                    FROM Rental 
                                    WHERE cid = ? AND Status = 'open';""",
                                (cid))

    data = count_cursor.fetchall()
    
    if len(data) != 0:
        countcid = data[0][0]

    cursor_pid = conn.execute("""SELECT pid FROM Customer 
                                WHERE cid = ?;""", 
                            (cid))

    data = cursor_pid.fetchall()
    
    if len(data) != 0:
        pid = data[0][0]
    
    n_cursor = conn.execute("""SELECT max_movies- ? 
                                FROM RentalPlan 
                                WHERE pid = ?;""", 
                            (countcid, pid))
   
    data = n_cursor.fetchall()
    
    if len(data) != 0:
        n = data[0][0]
    
    if n < 1:
        response = {"rent": "fail"}
        success = 1

    if success == 0:
        conn.execute("""INSERT INTO RENTAL(cid, mid, date_and_time, status) VALUES (?, ?, ?, ?)""",
                    (cid, mid, currentTime(), 'open'))

    conn.autocommit = True
    return jsonify(response)
